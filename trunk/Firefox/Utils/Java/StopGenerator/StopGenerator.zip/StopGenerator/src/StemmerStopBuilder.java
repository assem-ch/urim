import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.tartarus.snowball.SnowballStemmer;

public class StemmerStopBuilder {
	static String[] stemmers = { "danish", "dutch", "english", "finnish",
			"french", "german", "hungarian", "italian", "norwegian",
			"portuguese", "russian", "spanish", "swedish" };

	static String[] stopArray = { "da", "de", "en", "fi", "fr", "de", "hu",
			"it", "no", "pt", "ru", "es", "sv", "ua" };

	/**
	 * @param args
	 */

	public static void main(String[] args) {
		try {

			ArrayList<String> stopList = new ArrayList<String>();

			for (String stopItem : stopArray) {
				BufferedReader in = new BufferedReader(new InputStreamReader(
						new FileInputStream("stop/" + stopItem + ".txt"), "UTF-8"));

				String line = null;
				while ((line = in.readLine()) != null) {
					String trimedLine = line.trim();
					if (trimedLine.isEmpty())
						continue;
					stopList.add(trimedLine);
				}

				in.close();
			}

			System.out.println("read " + stopList.size() + " words");

			Set<String> stopSet = new HashSet<String>();

			for (String stemmerLanguage : stemmers) {
				System.out.println(stemmerLanguage);

				Class<?> stemClass = Class.forName("org.tartarus.snowball.ext."
						+ stemmerLanguage + "Stemmer");
				SnowballStemmer stemmer = (SnowballStemmer) stemClass
						.newInstance();

				for (String stopWord : stopList) {
					StringBuilder sb = new StringBuilder();

					for (String part : stopWord.split(" ")) {
						if (sb.length() > 0)
							sb.append(" ");
						stemmer.setCurrent(part);
						stemmer.stem();
						sb.append(stemmer.getCurrent());
					}

					stopSet.add(sb.toString());
				}
			}

			System.out.println("unique stemed " + stopSet.size() + " words");

			File file = new File("StemmerStopBuilder.js");
			FileOutputStream fos = new FileOutputStream(file);
			fos.write("var stopList = {\n\t".getBytes("UTF-8"));
			boolean isFirst = true;

			for (String stemStopWord : stopSet) {
				StringBuffer line = new StringBuffer();
				if (!isFirst)
					line.append(",\n\t");
				else
					isFirst = false;
				line.append(javaStringLiteral(stemStopWord) + " : null");

				fos.write(line.toString().getBytes("UTF-8"));
			}

			fos.write("\n};".getBytes("UTF-8"));
			fos.flush();
			fos.close();
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	/*
	 * http://stackoverflow.com/questions/2453231/how-would-you-convert-a-string-
	 * to-a-java-string-literal
	 */
	private static String javaStringLiteral(String str) {
		StringBuilder sb = new StringBuilder("\"");
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if (c == '\n') {
				sb.append("\\n");
			} else if (c == '\r') {
				sb.append("\\r");
			} else if (c == '"') {
				sb.append("\\\"");
			} else if (c == '\\') {
				sb.append("\\\\");
			} else if (c < 0x20) {
				sb.append(String.format("\\%03o", (int) c));
			} else if (c >= 0x80) {
				sb.append(String.format("\\u%04x", (int) c));
			} else {
				sb.append(c);
			}
		}
		sb.append("\"");
		return sb.toString();
	}
}
