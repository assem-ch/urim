import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class LanguageIdentifierTestBuilder {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {

			BufferedReader in = new BufferedReader(new InputStreamReader(
					new FileInputStream("text/test-referencial.txt")));

			String line = null;
			boolean isFirst = true;
			StringBuffer buffer = new StringBuffer("var testArray = [");

			while ((line = in.readLine()) != null) {
				String[] tokens = line.split(";");
				if (!tokens[0].equals("")) {
					System.out.println(tokens[0]);
					String text = readInputStreamAsString(new FileInputStream(
							"text/" + tokens[0]));

					if (!isFirst)
						buffer.append(",\n");
					isFirst = false;

					buffer.append("{ text: " + javaStringLiteral(text)
							+ ", language: \"" + tokens[1] + "\"}");

				}
			}
			in.close();
			buffer.append("];");

			File f = new File("LanguageIdentifierTest.js");
			FileOutputStream fos = new FileOutputStream(f);
			fos.write(buffer.toString().getBytes("UTF-8"));

			fos.flush();
			fos.close();

		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	/*
	 * http://stackoverflow.com/questions/2453231/how-would-you-convert-a-string-
	 * to-a-java-string-literal
	 */
	private static String javaStringLiteral(String str) {
		StringBuilder sb = new StringBuilder("\"");
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if (c == '\n') {
				sb.append("\\n");
			} else if (c == '\r') {
				sb.append("\\r");
			} else if (c == '"') {
				sb.append("\\\"");
			} else if (c == '\\') {
				sb.append("\\\\");
			} else if (c < 0x20) {
				sb.append(String.format("\\%03o", (int) c));
			} else if (c >= 0x80) {
				sb.append(String.format("\\u%04x", (int) c));
			} else {
				sb.append(c);
			}
		}
		sb.append("\"");
		return sb.toString();
	}

	private static String readInputStreamAsString(InputStream in)
			throws IOException {

		BufferedInputStream bis = new BufferedInputStream(in);
		ByteArrayOutputStream buf = new ByteArrayOutputStream();
		int result = bis.read();
		while (result != -1) {
			byte b = (byte) result;
			buf.write(b);
			result = bis.read();
		}

		in.close();
		return buf.toString("UTF-8");
	}
}
