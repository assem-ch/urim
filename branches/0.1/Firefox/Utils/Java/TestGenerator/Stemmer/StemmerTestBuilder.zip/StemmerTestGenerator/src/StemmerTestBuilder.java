import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class StemmerTestBuilder {

	/**
	 * @param args
	 */

	static String[] algoritms = { "danish", "dutch", "english", "finnish",
			"french", "german", "hungarian", "italian", "norwegian",
			"portuguese", "russian", "spanish", "swedish" };

	public static void main(String[] args) {
		try {

			for (String algoritm : algoritms) {
				System.out.println(algoritm);
				int count = 0;
				int gCount = 0;
				StringBuffer gBuffer = new StringBuffer();
				StringBuffer buffer = new StringBuffer("const " + algoritm
						+ "TestDiffs" + gCount + " = {\n");
				boolean isFirst = true;

				for (String line : createTest(algoritm)) {
					count++;
					if (!isFirst)
						buffer.append(",\n");
					isFirst = false;

					buffer.append("\t" + line);

					if (count >= 250) {
						count = 0;
						isFirst = true;
						buffer.append("\n};");
						gBuffer.append(buffer);
						gCount++;

						gBuffer.append("\n\n");
						buffer = new StringBuffer("const " + algoritm
								+ "TestDiffs" + gCount + " = {\n");

					}
				}

				buffer.append("\n};");
				gBuffer.append(buffer);
				gBuffer.append("\n");

				for (int i = gCount; i >= 0; i--) {
					gBuffer.append("\n");
					gBuffer.append("var test" + algoritm + i
							+ " = function() {\n");
					gBuffer.append("\tvar buffer, fails = 0, total = 0;\n");
					gBuffer.append("\tfor (var sVoc in " + algoritm
							+ "TestDiffs" + i + ") {\n");
					gBuffer.append("\t\ttotal++;\n");
					gBuffer.append("\t\tvar base = " + algoritm + "TestDiffs"
							+ i + "[sVoc];\n");
					gBuffer.append("\t\tvar stem = stemmer(sVoc);\n");
					gBuffer.append("\t\tif (base != stem) {\n");
					gBuffer.append("\t\t\tfails++;\n");
					gBuffer.append("\t\t\tif (buffer) {\n");
					gBuffer.append("\t\t\t\tbuffer += \"; \";\n");
					gBuffer
							.append("\t\t\t\tbuffer += sVoc + \" --> \" + base + \" | \" + stem;\n");
					gBuffer.append("\t\t} else\n");
					gBuffer
							.append("\t\t\t\tbuffer = sVoc + \" --> \" + base + \" | \" + stem;\n");
					gBuffer.append("\t\t}\n");
					gBuffer.append("\t}\n");
					gBuffer
							.append("\tjumlib.assertUndefined(buffer, \"Total:\" + total + \", fails: \" + fails);\n");
					gBuffer.append("}\n");
				}

				File file = new File(algoritm + "StemmerTest.js");
				FileOutputStream fos = new FileOutputStream(file);
				fos.write(gBuffer.toString().getBytes("UTF-8"));

				fos.flush();
				fos.close();
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}
	}

	private static ArrayList<String> createTest(String algoritm)
			throws IOException {

		BufferedReader voc = new BufferedReader(new InputStreamReader(
				new FileInputStream("data/" + algoritm + "/voc.txt")));
		BufferedReader out = new BufferedReader(new InputStreamReader(
				new FileInputStream("data/" + algoritm + "/output.txt")));

		ArrayList<String> stemList = new ArrayList<String>();

		String line = null;
		while ((line = voc.readLine()) != null) {
			if (line.isEmpty())
				continue;

			String lineOut = out.readLine();

			String word = javaStringLiteral(line);
			String stem = javaStringLiteral(lineOut);

			String pair = word + " : " + stem;
			stemList.add(pair);
		}

		voc.close();
		out.close();

		return stemList;
	}

	/*
	 * http://stackoverflow.com/questions/2453231/how-would-you-convert-a-string-
	 * to-a-java-string-literal
	 */
	private static String javaStringLiteral(String str) {
		StringBuilder sb = new StringBuilder("\"");
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if (c == '\n') {
				sb.append("\\n");
			} else if (c == '\r') {
				sb.append("\\r");
			} else if (c == '"') {
				sb.append("\\\"");
			} else if (c == '\\') {
				sb.append("\\\\");
			} else if (c < 0x20) {
				sb.append(String.format("\\%03o", (int) c));
			} else if (c >= 0x80) {
				sb.append(String.format("\\u%04x", (int) c));
			} else {
				sb.append(c);
			}
		}
		sb.append("\"");
		return sb.toString();
	}
}
